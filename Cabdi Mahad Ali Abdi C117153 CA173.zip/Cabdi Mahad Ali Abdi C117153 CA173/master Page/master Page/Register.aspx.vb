﻿Public Class Register
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub txtDateOFBirth_TextChanged(sender As Object, e As EventArgs) Handles txtDateOFBirth.TextChanged
        If txtDateOFBirth.Text = String.Empty Then
            txtAge.Text = ""
        Else
            Dim birth As DateTime
            Dim today As DateTime
            birth = CDate(txtDateOFBirth.Text)
            today = Now.ToString("d")
            Dim span As TimeSpan
            span = today - birth
            Dim day As Double
            day = span.TotalDays
            txtAge.Text = (day / 365).ToString("0")
        End If
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        lblmesseg.Text = "Created"
    End Sub
End Class