﻿Public Class contact
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        txtDate.Text = Now.ToString("d")
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        lblmsg.text = "Account Created "
    End Sub

End Class