﻿Public Class WebForm1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
      
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
      
        If txtUsername.Text = "cmc" And txtPassword.Text = "cmc" Then
            Response.Redirect("Home.aspx")
        End If
    End Sub

End Class